const createNewsCategoryQuery = `INSERT INTO categories (uuid , name ) VALUES(?) `;

export { createNewsCategoryQuery };
